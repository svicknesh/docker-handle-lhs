/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.util;

import java.io.*;

public class IOForwarder
  implements Runnable
{
  private InputStream in;
  private OutputStream out;
  public Exception err = null;
  public boolean finished = false;
  boolean debug = false;
  
  public IOForwarder(InputStream in, OutputStream out) {
    this.in = in;
    this.out = out;
  }

  public static final void forwardStream(InputStream in, OutputStream out)
    throws IOException
  {
    byte buf[] = new byte[4096];
    int r;
    while((r=in.read(buf))>=0) {
      out.write(buf, 0, r);
      if(r==0) {
        // throttle to prevent spinning out
        try { Thread.sleep(100); } catch (Throwable e) {}
      }
    }
    out.flush();
  }
  
  public void run() {
    try {
      forwardStream(in, out);
    } catch (Exception e) {
      this.err = e;
    } finally {
      if(debug) System.err.println("finished writing");
      this.finished = true;
      try { out.close(); } catch (Exception e) {
        System.err.println("Error closing stream: "+e);
        e.printStackTrace(System.err);
      }
    }
  }
}

  
    
