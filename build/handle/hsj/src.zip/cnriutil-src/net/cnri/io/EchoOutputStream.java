/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.io;

import java.io.*;

/** This class provides a wrapper around an output stream that prints
 out whatever is written to the given OutputStream. */

public class EchoOutputStream
  extends OutputStream
  {
    private OutputStream out;
    private OutputStream echoOut;
    private boolean closeWhenFinished;
    
    public EchoOutputStream(OutputStream out) {
      this(out, System.err, false);
    }
    
    public EchoOutputStream(OutputStream out, OutputStream echoOut) {
      this(out, echoOut, true);
    }
    
    public EchoOutputStream(OutputStream out, OutputStream echoOut,
                            boolean closeWhenFinished) {
      this.out = out;
      this.echoOut = echoOut;
      this.closeWhenFinished = closeWhenFinished;
    }
    
    public void write(int b)
    throws IOException
    {
      out.write(b);
      echoOut.write(b);
    }
    
    public void write(byte b[])
    throws IOException
    {
      out.write(b);
      echoOut.write(b);
    }
    
    public void write(byte b[], int offset, int len)
    throws IOException
    {
      out.write(b, offset, len);
      echoOut.write(b, offset, len);
    }
    
    public void close()
    throws IOException
    {
      out.close();
      if(closeWhenFinished) echoOut.close();
    }
    
    public void flush()
    throws IOException
    {
      out.flush();
      echoOut.flush();
    }
  }

