/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.xml.node;

import java.io.IOException;
import java.io.StringReader;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLResolver;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class Parser {
    private Parser() {}
    
    private static void setFactoryProperty(XMLInputFactory factory, String name, Object value) {
        if(factory.isPropertySupported(name)) {
            try {
                factory.setProperty(name,value);
            }
            catch (IllegalArgumentException e) { 
                //ignore
            }
        }
    }
    
    // possibility of reusing factory... some implementations are thread-safe...
    public static XMLInputFactory getFactory() {
        XMLInputFactory factory = XMLInputFactory.newInstance();
        setFactoryProperty(factory,XMLInputFactory.IS_VALIDATING,Boolean.FALSE);
        setFactoryProperty(factory,XMLInputFactory.IS_COALESCING,Boolean.TRUE);
//        setFactoryProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES,Boolean.FALSE);
//        setFactoryProperty(XMLInputFactory.SUPPORT_DTD,Boolean.FALSE);
        factory.setXMLResolver(new XMLResolver() {
            @Override
            public Object resolveEntity(String publicID, String systemID, String baseURI, String namespace) throws XMLStreamException {
                throw new XMLStreamException("External entity " + systemID);
                //return new ByteArrayInputStream(new byte[0]);
            }
        });
        return factory;
    }
    
    public static Node parse(String xml) throws XMLStreamException {
        return parse(xml,false);
    }
    public static Node parse(String xml,boolean globalizeNamespaces) throws XMLStreamException {
        XMLStreamReader reader = getFactory().createXMLStreamReader(new StringReader(xml));
        Deque<ElementNodeImpl> nodes = new LinkedList<ElementNodeImpl>();
        StringBuilder text = null;
        try {
            while(reader.hasNext()) {
                if(reader.isStartElement()) {
                    if(text!=null) {
                        if(nodes.isEmpty()) throw new XMLStreamException("text outside element",reader.getLocation());
                        ElementNodeImpl parent = nodes.getFirst();
                        parent.addChild(new TextNodeImpl(text.toString()));
                        text = null;
                    }
                    QName name = reader.getName();
                    Map<QName,String> attributes = null;
                    if(reader.getAttributeCount() > 0) {
                        attributes = new LinkedHashMap<QName,String>();
                        for(int i = 0; i < reader.getAttributeCount(); i++) {
                            attributes.put(reader.getAttributeName(i),reader.getAttributeValue(i));
                        }
                    }
                    Map<String,String> namespaceDeclarations = null;
                    if(reader.getNamespaceCount() > 0) {
                        namespaceDeclarations = new LinkedHashMap<String,String>();
                        for(int i = 0; i < reader.getNamespaceCount(); i++) {
                            String prefix = reader.getNamespacePrefix(i);
                            if(prefix==null) prefix="";
                            String nsURI = reader.getNamespaceURI(i);
                            if(nsURI==null) nsURI="";
                            namespaceDeclarations.put(prefix,nsURI);
                        }
                    }
                    
                    Map<String,String> namespaceContext;
                    if(globalizeNamespaces) {
                        namespaceContext = null;
                    }
                    else if(nodes.isEmpty()) {
                        namespaceContext = namespaceDeclarations;
                    }
                    else {
                        if(namespaceDeclarations==null || namespaceDeclarations.isEmpty()) namespaceContext = nodes.getFirst().getNamespaceContext();
                        else {
                            namespaceContext = new HashMap<String,String>(nodes.getFirst().getNamespaceContext());
                            namespaceContext.putAll(namespaceDeclarations);
                        }
                    }

                    nodes.push(new ElementNodeImpl(name,attributes,namespaceDeclarations,namespaceContext));
                }
                else if (reader.isEndElement()) {
                    if(nodes.isEmpty()) throw new XMLStreamException("end element before start element",reader.getLocation());
                    ElementNodeImpl element = nodes.pop();
                    if(text!=null) {
                        element.addChild(new TextNodeImpl(text.toString()));
                        text = null;
                    }
                    if(nodes.isEmpty()) {
                        if(globalizeNamespaces) element.globalizeNamespaces();
                        element.makeImmutable();
                        return element;
                    }
                    else {
                        ElementNodeImpl parent = nodes.getFirst();
                        parent.addChild(element);
                    }
                }
                else if(reader.isCharacters() && reader.getTextLength()>0) {
                    if(text==null) text = new StringBuilder(reader.getText());
                    else text.append(reader.getText());
                }
//                else {
//                    System.out.println(reader.getEventType());
//                }
                reader.next();
            }
            throw new XMLStreamException("missing end element");
        }
        finally {
            reader.close();
        }
    }

    public static void escape(Appendable buf, CharSequence s, boolean quot, boolean apos) throws IOException {
        int len = s.length();
        for(int i = 0; i < len; i++) {
            char c = s.charAt(i);
            if(c=='&') buf.append("&amp;");
            else if(c=='<') buf.append("&lt;");
            else if(c=='>') buf.append("&gt;");
            else if(c=='"' && quot) buf.append("&quot;");
            else if(c=='\'' && apos) buf.append("&apos;");
            else if(c==0x9) buf.append("&#x9;");
            else if(c==0xD) buf.append("&#xD;");
            else if(c==0xA && (quot || apos)) buf.append("&#xA;"); // escape newlines in attributes
            else buf.append(c);
        }
    }

    public static void append(Appendable buf,Node node,boolean root) throws IOException {
        if(node.isText()) escape(buf,node.getText(),false,false);
        else {
            buf.append("<");
            String prefix = node.getPrefix();
            if(prefix!=null && !prefix.isEmpty()) buf.append(prefix).append(":");
            buf.append(node.getLocalName());
            for(Map.Entry<String,String> namespaceDeclaration : (root?node.getNamespaceContext():node.getNamespaceDeclarations()).entrySet()) {
                buf.append(" xmlns");
                if(namespaceDeclaration.getKey()!=null && !namespaceDeclaration.getKey().isEmpty()) buf.append(":").append(namespaceDeclaration.getKey());
                buf.append("=\"");
                escape(buf,namespaceDeclaration.getValue(),true,false);
                buf.append("\"");
            }
            for(Map.Entry<QName,String> attribute : node.getAttributes().entrySet()) {
                buf.append(" ");
                String attrPrefix = attribute.getKey().getPrefix();
                if(attrPrefix!=null && !attrPrefix.isEmpty()) buf.append(attrPrefix).append(":");
                buf.append(attribute.getKey().getLocalPart());
                buf.append("=\"");
                escape(buf,attribute.getValue(),true,false);
                buf.append("\"");
            }
            List<Node> children = node.getChildren();
            if(children.isEmpty()) buf.append("/>");
            else {
                buf.append(">");
                for(Node child : children) {
                    append(buf,child,false);
                }
                buf.append("</");
                if(prefix!=null && !prefix.isEmpty()) buf.append(prefix).append(":");
                buf.append(node.getLocalName());
                buf.append(">");
            }
        }
    }
    
    public static void append(StringBuilder buf,Node node,boolean root) {
        try {
            append((Appendable)buf,node,root);
        }
        catch(IOException e) {
            throw new AssertionError(e);
        }
    }
}
