/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.
               
        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
         http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.cnri.xml.node;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

class ElementNodeImpl implements Node {
    private QName name;
    private Map<QName,String> attributes;
    private List<Node> children;
    private List<Node> elementChildren;
    private Map<String,String> namespaceDeclarations;
    private Map<String,String> namespaceContext;

    ElementNodeImpl(QName name, Map<QName,String> attributes, Map<String,String> namespaceDeclarations, Map<String,String> namespaceContext) {
        this.name = name;
        this.attributes = attributes;
        this.namespaceDeclarations = namespaceDeclarations;
        this.namespaceContext = namespaceContext;
    }
    
    void addChild(Node child) {
        boolean shared = children==elementChildren;
        if(child.isText()) {
            if(children==null) children = new ArrayList<Node>();
            else if(shared) children = new ArrayList<Node>(elementChildren);
            children.add(child);
        }
        else {
            if(children==null) children = new ArrayList<Node>();
            if(elementChildren==null) {
                if(shared) elementChildren = children;
                else elementChildren = new ArrayList<Node>();
            }
            children.add(child);
            if(!shared) elementChildren.add(child);
        }
    }
    
    void makeImmutable() {
        Map<String,String> oldNamespaceContext = namespaceContext;
        if(namespaceContext==null) namespaceContext = Collections.<String,String>emptyMap();
        else namespaceContext = Collections.unmodifiableMap(namespaceContext);
        makeImmutable(oldNamespaceContext,namespaceContext);
    }
    
    private void makeImmutable(Map<String,String> origNamespaceContext, Map<String,String> fixedNamespaceContext) {
        if(attributes==null) attributes = Collections.<QName,String>emptyMap();
        else attributes = Collections.unmodifiableMap(attributes);
        
        boolean sharedChildren = children==elementChildren;
        if(children==null) children = Collections.<Node>emptyList();
        else children = Collections.unmodifiableList(children);
        if(sharedChildren) elementChildren = children;
        else {
            if(elementChildren==null) elementChildren = Collections.<Node>emptyList();
            else elementChildren = Collections.unmodifiableList(elementChildren);
        }
        
        boolean sharedNamespaces = namespaceDeclarations==namespaceContext;
        Map<String,String> oldNamespaceContext = namespaceContext;
        if(namespaceContext==origNamespaceContext) namespaceContext = fixedNamespaceContext;
        else {
            if(namespaceContext==null) namespaceContext = Collections.<String,String>emptyMap();
            else namespaceContext = Collections.unmodifiableMap(namespaceContext);
        }
        if(sharedNamespaces) namespaceDeclarations = namespaceContext;
        else {
            if(namespaceDeclarations==null) namespaceDeclarations = Collections.<String,String>emptyMap();
            else namespaceDeclarations = Collections.unmodifiableMap(namespaceDeclarations);
        }
        
        for(Node child : elementChildren) {
            if(child instanceof ElementNodeImpl) {
                ((ElementNodeImpl)child).makeImmutable(oldNamespaceContext,namespaceContext);
            }
        }
    }

    private static final String XML_NAMESPACE = "http://www.w3.org/XML/1998/namespace";
    
    private static String globalizeNamespaces(String aPrefix, String uri, Map<String,String> aNamespaceContext, Map<String,String> reverseNamespaceContext, boolean noDefault) {
        String prefix = aPrefix;
        if(uri.isEmpty() && !prefix.isEmpty()) {
            prefix = "";
        }
        if(prefix.isEmpty() && !uri.isEmpty() && noDefault) {
            prefix = "ns";
        }

        String defaultNamespace = aNamespaceContext.get("");
        if(!noDefault && uri.equals(defaultNamespace)) {
            return "";
        }
        if(prefix.isEmpty() && defaultNamespace==null && !uri.equals(XML_NAMESPACE)) {
            aNamespaceContext.put("",uri);
            return "";
        }
        
        String priorPrefix = reverseNamespaceContext.get(uri);
        if(priorPrefix!=null) {
            return priorPrefix;
        }
        else {
            String priorURI = prefix.isEmpty() ? defaultNamespace : aNamespaceContext.get(prefix);
            if(priorURI==null) {
                aNamespaceContext.put(prefix,uri);
                if(!prefix.isEmpty()) reverseNamespaceContext.put(uri,prefix);
                return prefix;
            }
            else {
                if(uri.isEmpty()) {
                    // can't change the prefix; so change the prior default
                    if(reverseNamespaceContext.get(defaultNamespace)==null) {
                        for(int i = 1; true; i++) {
                            String newPrefix = "ns" + i;
                            String existingURI = aNamespaceContext.get(newPrefix);
                            if(existingURI==null) {
                                aNamespaceContext.put(newPrefix,priorURI);
                                reverseNamespaceContext.put(priorURI,newPrefix);
                                aNamespaceContext.put("","");
                                return "";
                            }
                        }
                    }
                    else {
                        aNamespaceContext.put("","");
                        return "";
                    }
                }
                else {
                    if(prefix.isEmpty()) prefix = "ns";
                    else if(Character.isDigit(prefix.charAt(prefix.length()-1))) prefix = prefix + "_";
                    for(int i = 1; true; i++) {
                        String newPrefix = prefix + i;
                        priorURI = aNamespaceContext.get(newPrefix);
                        if(priorURI==null) {
                            aNamespaceContext.put(newPrefix,uri);
                            reverseNamespaceContext.put(uri,newPrefix);
                            return newPrefix;
                        }
                    }
                }
            }
        }
    }
    
    private void globalizeNamespaces(Map<String,String> aNamespaceContext, Map<String,String> reverseNamespaceContext) {
        String newPrefix = globalizeNamespaces(name.getPrefix(),name.getNamespaceURI(),aNamespaceContext,reverseNamespaceContext,false);
        if(!newPrefix.equals(name.getPrefix())) name = new QName(name.getNamespaceURI(),name.getLocalPart(),newPrefix);
        if(attributes!=null) {
            for(QName attrName : attributes.keySet()) {
                String attrPrefix = attrName.getPrefix();
                String attrURI = attrName.getNamespaceURI();
                if(!attrURI.isEmpty()) {
                    String newAttrPrefix = globalizeNamespaces(attrPrefix,attrURI,aNamespaceContext,reverseNamespaceContext,true);
                    if(!newAttrPrefix.equals(attrPrefix)) {
                        QName newAttrName = new QName(attrURI,attrName.getLocalPart(),newAttrPrefix);
                        attributes.put(newAttrName,attributes.remove(attrName));
                    }
                }
                else if(!attrPrefix.isEmpty()) {
                    attributes.put(new QName("",attrName.getLocalPart()),attributes.remove(attrName));
                }
            }
        }
        if(elementChildren!=null) {
            for(Node child : elementChildren) {
                if(child instanceof ElementNodeImpl) ((ElementNodeImpl)child).globalizeNamespaces(aNamespaceContext,reverseNamespaceContext);
            }
        }
        namespaceContext = aNamespaceContext;
        namespaceDeclarations = null;
    }
    
    void globalizeNamespaces() {
        Map<String,String> newNamespaceContext = new LinkedHashMap<String,String>();
        newNamespaceContext.put("xml",XML_NAMESPACE);
        Map<String,String> reverseNamespaceContext = new HashMap<String,String>();
        reverseNamespaceContext.put(XML_NAMESPACE,"xml");
        globalizeNamespaces(newNamespaceContext,reverseNamespaceContext);
        // Have to check for change in default namespace
        String defaultNamespace = newNamespaceContext.get("");
        if(defaultNamespace!=null) {
            if(!defaultNamespace.isEmpty()) {
                newNamespaceContext.remove(reverseNamespaceContext.get(defaultNamespace));
                reverseNamespaceContext.remove(defaultNamespace);
            }
            globalizeNamespaces(newNamespaceContext,reverseNamespaceContext);
            if(defaultNamespace.isEmpty()) newNamespaceContext.remove("");
        }
        newNamespaceContext.remove("xml");
        namespaceDeclarations = namespaceContext;
    }
    
    public QName getName() {
        return name;
    }
    
    public String getNamespaceURI() {
        if(name==null) return null;
        return name.getNamespaceURI();
    }

    public String getPrefix() {
        if(name==null) return null;
        return name.getPrefix();
    }

    public String getLocalName() {
        if(name==null) return null;
        return name.getLocalPart();
    }

    public String getAttribute(String attrName) {
        if(attributes==null) return null;
        return attributes.get(new QName(attrName));
    }
    
    public String getAttribute(QName qname) {
        if(attributes==null) return null;
        return attributes.get(qname);
    }
    
    public Map<QName,String> getAttributes() {
        return attributes;
    }
    
    public List<Node> getChildren() {
        return children;
    }

    public Map<String,String> getNamespaceDeclarations() {
        return namespaceDeclarations;
    }

    public Map<String,String> getNamespaceContext() {
        return namespaceContext;
    }

    public boolean isText() {
        return false;
    }
    
    public String getText() {
        if(children==null) return null;
        if(children.isEmpty()) return "";
        if(children.size()>1) return null;
        return children.get(0).getText();
    }
    
    public List<Node> getSubElements() {
        return elementChildren;
    }
    
    public Node getSubElement(String elementName) {
        if(elementChildren==null) return null;
        for(Node node : elementChildren) {
            if(elementName.equals(node.getLocalName())) return node;
        }
        return null;
    }
    
    public Node getSubElement(QName qname) {
        if(elementChildren==null) return null;
        for(Node node : elementChildren) {
            if(qname.equals(node.getName())) return node;
        }
        return null;
    }
    
    public String getSubElementText(String elementName) {
        if(elementChildren==null) return null;
        for(Node node : elementChildren) {
            if(elementName.equals(node.getLocalName())) return node.getText();
        }
        return null;
    }
    
    public String getSubElementText(QName qname) {
        if(elementChildren==null) return null;
        for(Node node : elementChildren) {
            if(qname.equals(node.getName())) return node.getText();
        }
        return null;
    }
    
    public List<Node> getSubElements(String elementName) {
        if(elementChildren==null || elementChildren.isEmpty()) return elementChildren;
        List<Node> res = new ArrayList<Node>(elementChildren.size());
        for(Node node : elementChildren) {
            if(elementName.equals(node.getLocalName())) res.add(node);
        }
        return res;
    }
    
    public List<Node> getSubElements(QName qname) {
        if(elementChildren==null || elementChildren.isEmpty()) return elementChildren;
        List<Node> res = new ArrayList<Node>(elementChildren.size());
        for(Node node : elementChildren) {
            if(qname.equals(node.getName())) res.add(node);
        }
        return res;
    }

    public String toString() {
        StringBuilder res = new StringBuilder();
        Parser.append(res,this,true);
        return res.toString();
    }
}
