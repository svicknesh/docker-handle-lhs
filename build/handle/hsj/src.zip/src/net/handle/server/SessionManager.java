/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
          http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.handle.server;

import net.handle.hdllib.*;

import java.util.*;
import java.security.*;


public class SessionManager {

  //the number of anonymousSession 
  private static int maxAnonymousSession = 10;
  
  private Hashtable sessionInfoDict = new Hashtable(10); 
  
  //the hash table to store the session options for client side
  //key will be the (auth handle | auth index)
  private Hashtable sessionOptionsDict = new Hashtable(10);
  
  private boolean keepRunning = true;

  private static Random sessionRandom;
  private static String sessionRandomLock = "sessionRandomLock";

  public static final int SESSION_NOT_AVAILABLE = -100;
  public static final int SESSION_MAXNUM_PER_SERVER = 10;
    
  public SessionManager(){ }
  

  public ServerSideSessionInfo getSession(int sessionId)  //SERVER side only
  {
      //server side dict is a Hashtable;
      //the keys are session ids, values are ServerSideSessionInfo.
      //it could be an anonymous session record
      ServerSideSessionInfo ssinfo = (ServerSideSessionInfo)sessionInfoDict.get(Integer.valueOf(sessionId));
      if (ssinfo != null) {
        ssinfo.touch();
        return ssinfo;
      }
     
      return null;
  }
  
  /** to remove a session info entry from session manager.
  */
  public void removeSession(int sessionId)
  {
      synchronized (sessionInfoDict) {
        sessionInfoDict.remove(new Integer(sessionId));
      }
  }
  
  
  /* 
     replace the old session info with the new session info*/
  public boolean replaceServerSideSessionInfo(int sessionId, ServerSideSessionInfo newInfo)
  {
    if (newInfo == null) {
      System.err.println("The new session info is null. No info is replaced.");  
      return true;
    }
    
    if (newInfo instanceof ServerSideSessionInfo) {
      synchronized (sessionInfoDict) {
        sessionInfoDict.remove(new Integer(sessionId));
        sessionInfoDict.put(new Integer(sessionId), newInfo);
      }
      newInfo.touch();
      return true;
    }
    return false;
  }


  public boolean addSession(ServerSideSessionInfo sessionInfo) throws HandleException
  {
    if (sessionInfo == null) return true;
        //server side manager adds a session info
        ServerSideSessionInfo ssinfo = (ServerSideSessionInfo)sessionInfo;
        synchronized(sessionInfoDict) {
          sessionInfoDict.put(new Integer(ssinfo.sessionId), ssinfo);
        }

        sessionInfo.touch();
        return true;
  }
  
  public void checkTimeoutSession()
  {
    // start thread to purge timed-out ServerSideSessionInfo, i.g. Session objects.
    // thus the session will not hang on for days...
    CheckSessionTimeOut cst = new CheckSessionTimeOut();
    cst.setDaemon(true);
    cst.setPriority(Thread.MIN_PRIORITY);
    cst.start();
  }
  
  public Vector getSessions() {
    
      //return an enumeration of ServerSessionInfo
      Vector vecSessions = new Vector();
      Enumeration enumSession = sessionInfoDict.elements();
      while (enumSession.hasMoreElements()) {
        ServerSideSessionInfo sssinfo = (ServerSideSessionInfo)enumSession.nextElement();
        vecSessions.addElement(sssinfo);
      }
      return vecSessions;
      
  }
  
  public Vector getSessions(AuthenticationInfo info) {
    if (info!= null)
      return getSessions(info.getUserIdHandle(), info.getUserIdIndex());
    else return null;
  }
    
  public Vector getSessions(byte identityHandle[], int identityIndex) {
      //return an enumeration of ServersideServerSideSessionInfo
      Vector vecSessions = new Vector();
      Enumeration enumSession = sessionInfoDict.elements();
      while (enumSession.hasMoreElements()) {
        ServerSideSessionInfo sssinfo = (ServerSideSessionInfo)enumSession.nextElement();
        if (Util.equals(sssinfo.identityKeyHandle, identityHandle) &&
                        sssinfo.identityKeyIndex == identityIndex) {
          vecSessions.addElement(sssinfo);
        }
      }
      return vecSessions;
  }
   
  public Enumeration getAllKeys() {
    return sessionInfoDict.keys();
  }   
  
  public synchronized void shutdown() {
    if (!keepRunning) return;
    //to inform the checkSessionTimeOut thread to end
    keepRunning = false;
  }

  /* why we want to put the session time out checking in a seperate thread,
  *  we may want to check session time out on client side. 
  */
  private class CheckSessionTimeOut extends Thread {
    
    public void run(){
      while(keepRunning) {
        try {  
          Thread.sleep(60000);  //at least 1 minute
          //server side session manager is checking on session time out
        
          Enumeration enu = sessionInfoDict.keys();
          while (enu.hasMoreElements()) {
            Integer sessionId = (Integer)enu.nextElement();
          
            //can not use gerServerSideSessionInfo method here, that will touch
            //the "lastTransaction" field non-intentionally
            ServerSideSessionInfo ssinfo =
                (ServerSideSessionInfo)sessionInfoDict.get(sessionId);
            if (ssinfo != null && ssinfo.hasExpired()) {
              removeSession(sessionId.intValue());  //syncronized
            }
          }
        
        } //try ...
        catch (Throwable e) {
          System.err.println("Error purging timeout session objects: "+e);
        } 
      } 
    }
  } 

  
  /** generate random session key **/
  public static final byte[] getGeneratedSecretKey()
    throws HandleException
  {
    // generate a nonce to make this a unique non-repeatable challenge
    byte[] sessionKey = new byte[Common.SESSION_KEY_SIZE];
    getSessionRandom().nextBytes(sessionKey);

    return sessionKey;
  }


  public static final void initializeSessionKeyRandom() {
    initializeSessionKeyRandom(null);
  }

  public static final void initializeSessionKeyRandom(byte seed[]) {
    if(sessionRandom==null) {
      synchronized(sessionRandomLock) {
        if(sessionRandom==null) {
          if (seed == null) {
              sessionRandom = new SecureRandom();
              sessionRandom.setSeed(System.nanoTime());
          }
          else sessionRandom = new SecureRandom(seed);
          sessionRandom.nextInt();
        }
      }
    }
  }

  private static Random getSessionRandom() {
    if(sessionRandom==null)
      initializeSessionKeyRandom();
    return sessionRandom;
  }

}

