/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
          http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.handle.util;

import java.util.*;

public class LRUCacheTable<K,V> extends AbstractMap<K,V> {
  private int maxsize;
  private Map<K,V> map;
  
  public LRUCacheTable(int maxsize){
    this.maxsize = maxsize;
    map = Collections.synchronizedMap(new LinkedHashMap<K,V>(maxsize, 1.0F, true) {
        protected boolean removeEldestEntry(Map.Entry<K,V> eldest) {
            return super.size() >= LRUCacheTable.this.maxsize;
        }
    });
  }
  
  public int size() {
    return map.size();
  }
  
  public int getMaxSize(){
    return maxsize;
  }

  public void setMaxSize(int newsize) {
    maxsize = newsize;
  }
  
  public V put(K key, V val){
      return map.put(key, val);
  }

  public V remove(Object key) {
      return map.remove(key);
  }
  
  public void clear() {
      map.clear();
  }
  
  public V get(Object key){
      return map.get(key);
  }

  public Set<Map.Entry<K,V>> entrySet() {
      return map.entrySet();
  }

  public boolean containsKey(Object key) {
      return map.containsKey(key);
  }

  public boolean containsValue(Object value) {
      return map.containsValue(value);
  }

  public boolean isEmpty() {
      return map.isEmpty();
  }

  public Set<K> keySet() {
      return map.keySet();
  }

  public void putAll(Map<? extends K,? extends V> m) {
      map.putAll(m);
  }

  public Collection<V> values() {
      return map.values();
  }
}
