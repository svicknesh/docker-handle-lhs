/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
          http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

public class DefaultServlet extends HttpServlet {
    private final HttpServlet delegate;

    public DefaultServlet() {
        try {
            Class<?> delegateClass;
            try {
                delegateClass = Class.forName("org.eclipse.jetty.servlet.DefaultServlet");
            } catch(ClassNotFoundException e) {
                delegateClass = Class.forName("org.apache.catalina.servlets.DefaultServlet");
            }
            delegate = (HttpServlet)delegateClass.newInstance();
        } catch(Exception e) {
            throw new AssertionError(e);
        }
    }
    
    public void destroy() {
        delegate.destroy();
    }

    public String getInitParameter(String name) {
        return delegate.getInitParameter(name);
    }

    public Enumeration getInitParameterNames() {
        return delegate.getInitParameterNames();
    }

    public ServletConfig getServletConfig() {
        return delegate.getServletConfig();
    }

    public ServletContext getServletContext() {
        return delegate.getServletContext();
    }

    public String getServletInfo() {
        return delegate.getServletInfo();
    }

    public String getServletName() {
        return delegate.getServletName();
    }

    public void init() throws ServletException {
        delegate.init();
    }

    public void init(ServletConfig config) throws ServletException {
        delegate.init(config);
    }

    public void log(String message, Throwable t) {
        delegate.log(message, t);
    }

    public void log(String msg) {
        delegate.log(msg);
    }

    public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
        if(req instanceof HttpServletRequest && resp instanceof HttpServletResponse) {
            String pathInfo = ((HttpServletRequest) req).getPathInfo();
            if(pathInfo == null || pathInfo.startsWith("/WEB-INF/") || pathInfo.startsWith("/META-INF/")) {
                ((HttpServletResponse)resp).setStatus(HttpServletResponse.SC_FORBIDDEN);
                return;
            }
            req = new HttpServletRequestWrapper((HttpServletRequest)req) {
                @Override
                public String getServletPath() {
                    return "/";
                }
            };
        }
        delegate.service(req, resp);
    }
}
