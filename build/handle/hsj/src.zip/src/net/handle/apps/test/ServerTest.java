/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
          http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.handle.apps.test;

import net.cnri.util.StreamTable;
import net.handle.apps.simple.SiteInfoConverter;
import net.handle.hdllib.*;

import java.io.*;
import java.util.*;

/*******************************************************************
 Tests local handle server
 - Tests each interface (TCP, HTTP, UDP)
 - Prints to screen if interface passed or failed
 *******************************************************************/
public class ServerTest {
  private static final String HDL_TCP_CONFIG = "hdl_tcp_config";
  private static final String HDL_HTTP_CONFIG = "hdl_http_config";
  private static final String HDL_UDP_CONFIG = "hdl_udp_config";
  private static final String BIND_ADDRESS = "bind_address";
  private static final String BIND_PORT = "bind_port";
  private static final String SITE_INFO_FILE = "siteinfo.bin";
  private static final String SITE_INFO_JSON_FILE = "siteinfo.json";

  private static String TCPBindAddress;
  private static String TCPBindPort;
  private static String HTTPBindAddress;
  private static String HTTPBindPort;
  private static String UDPBindAddress;
  private static String UDPBindPort;

  private static Hashtable hdlTCP;
  private static Hashtable hdlHTTP;
  private static Hashtable hdlUDP;

  private static HandleResolver resolver = new HandleResolver();
  private static Configuration config = Configuration.defaultConfiguration();


  public ServerTest(StreamTable config, File configDir) {

    //look in config.dct file for TCP, HTTP, and UDP values	
    if(config.containsKey(HDL_TCP_CONFIG)){
      hdlTCP = (StreamTable)config.get(HDL_TCP_CONFIG);
      TCPBindAddress = String.valueOf(hdlTCP.get(BIND_ADDRESS));
      TCPBindPort = String.valueOf(hdlTCP.get(BIND_PORT));
    }
    if(config.containsKey(HDL_HTTP_CONFIG)){
      hdlHTTP = (StreamTable)config.get(HDL_HTTP_CONFIG);
      HTTPBindAddress = String.valueOf(hdlHTTP.get(BIND_ADDRESS));
      HTTPBindPort = String.valueOf(hdlHTTP.get(BIND_PORT));
    }
    if(config.containsKey(HDL_UDP_CONFIG)){
      hdlUDP = (StreamTable)config.get(HDL_UDP_CONFIG);
      UDPBindAddress = String.valueOf(hdlUDP.get(BIND_ADDRESS));
      UDPBindPort = String.valueOf(hdlUDP.get(BIND_PORT));
    }

    try{
        SiteInfo site;
        File siteInfoFile = new File(configDir, SITE_INFO_FILE);
        if(!siteInfoFile.exists() || !siteInfoFile.canRead()) {
            File siteInfoJsonFile = new File(configDir, SITE_INFO_JSON_FILE);
            if(!siteInfoJsonFile.exists() || !siteInfoJsonFile.canRead()) {
                System.err.println("Missing or inaccessible site info file: "+
                        siteInfoFile.getAbsolutePath() + "/" + siteInfoJsonFile.getName());
                throw new Exception("Missing or inaccessible site info file: "+
                        siteInfoFile.getAbsolutePath() + "/" + siteInfoJsonFile.getName());
            } else {
                byte[] siteInfoBytes = Util.getBytesFromFile(siteInfoJsonFile);
                try {
                    site = SiteInfoConverter.convertToSiteInfo(new String(siteInfoBytes,"UTF-8"));
                } catch(Throwable t) {
                    System.err.println("Missing or inaccessible site info file: "+
                            siteInfoFile.getAbsolutePath() + "/" + siteInfoJsonFile.getName());
                    throw new Exception("Missing or inaccessible site info file: "+
                            siteInfoFile.getAbsolutePath() + "/" + siteInfoJsonFile.getName(),t);
                }
            }
        }
        else {
            site = new SiteInfo();
            byte siteInfoBuf[] = new byte[(int)siteInfoFile.length()];
            InputStream in = new FileInputStream(siteInfoFile);
            try {
          	  int r, n = 0;
          	  while ((r = in.read(siteInfoBuf, n, siteInfoBuf.length - n)) > 0) n+= r;
            } finally {
          	  in.close();
            }
            Encoder.decodeSiteInfoRecord(siteInfoBuf, 0, site);
        }

      AbstractResponse response;
      Interface serverInterface;

      for(int j=0; j<site.servers.length; j++){
        System.out.println("SERVER: " + site.servers[j].getAddressString());

        //test each interface (TCP, HTTP, UDP)
        for(int k=0; k<site.servers[j].interfaces.length; k++){
          serverInterface = site.servers[j].interfaces[k];

          try{
            GenericRequest req = new GenericRequest(Common.BLANK_HANDLE, AbstractResponse.OC_GET_SITE_INFO, null);
            response = resolver.sendRequestToInterface(req, site.servers[j], serverInterface);

            System.out.print(Interface.protocolName(serverInterface.protocol));
            System.out.println(":"+serverInterface.port+"			***PASS***");

          } catch(HandleException t) {
            System.err.println("Server: " + site.servers[j].getAddressString());
            System.err.print(Interface.protocolName(serverInterface.protocol));
            System.err.print(":"+serverInterface.port+ "			***FAIL***");
            System.err.println("  "+HandleException.getCodeStr(t.getCode()));
          }
        }
      }
    }
    catch(Exception e) {
      System.err.println("Invalid site/server specification");
      System.err.println("Test Failed");
      System.exit(-1);

    }
  }
}
