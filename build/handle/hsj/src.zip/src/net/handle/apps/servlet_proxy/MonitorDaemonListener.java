package net.handle.apps.servlet_proxy;

import java.io.File;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import net.handle.server.MonitorDaemon;

public class MonitorDaemonListener implements ServletContextListener {
    private MonitorDaemon monitorDaemon;
    
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext context = sce.getServletContext();
        System.setProperty("java.library.path", context.getRealPath("/WEB-INF/lib/sigarlib/"));
        try {
            java.lang.reflect.Field fieldSysPath = ClassLoader.class.getDeclaredField("sys_paths");
            fieldSysPath.setAccessible(true);
            fieldSysPath.set(null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String path = context.getRealPath("");
        File dir = new File(path).getParentFile().getParentFile();
        monitorDaemon = new MonitorDaemon(60, System.currentTimeMillis(), null, null, null, null, dir);
        monitorDaemon.start();
        context.setAttribute(MonitorDaemon.class.getName(), monitorDaemon);
    }
    
    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        monitorDaemon.shutdown();
    }
}
