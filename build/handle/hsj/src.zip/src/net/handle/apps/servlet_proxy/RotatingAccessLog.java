/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
          http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.handle.apps.servlet_proxy;

import java.io.*;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import net.cnri.util.ThreadSafeDateFormat;
import net.handle.hdllib.*;

/*******************************************************************************
* Log class that writes error and log information to files that rotate on a 
* monthly or daily basis.
******************************************************************************/

public class RotatingAccessLog
  implements Runnable
{
  public static final int ACCESS_LOG_BUFFER_SIZE = 100000;
  public static final int EXTRA_LOG_BUFFER_SIZE = 100000;
  public static final int ERRLOG_LEVEL_EVERYTHING =   0;   // == log all messages
  public static final int ERRLOG_LEVEL_INFO       =  25;
  public static final int ERRLOG_LEVEL_NORMAL     =  50;
  public static final int ERRLOG_LEVEL_REALBAD    =  75;
  public static final int ERRLOG_LEVEL_FATAL      = 100;
  
  public static final int ROTATE_MONTHLY = 0;
  public static final int ROTATE_DAILY = 0;
  
  private int errorLoggingLevel = ERRLOG_LEVEL_INFO;     // Default logging level
    
  private File logDirectory = null;
  
  private Writer accessWriter = null;
  private Writer errorWriter = null;
  private Writer extraWriter = null;
  private ThreadSafeDateFormat errorLogDateFormat = null;
  
  private boolean continuing      = true; // Signal to keep going...or not
  private boolean loggingAccesses = true;
  private boolean loggingExtras   = false;
  
  private final String ERROR_LOG_LOCK  = "error_log_lock";
  private final String ACCESS_LOG_LOCK = "access_log_lock";
  
  private Thread flusherThread = null;
  private Thread rotaterThread = null;

  private AtomicInteger requestsCurrentMinute = new AtomicInteger();
  private AtomicInteger requestsPastMinute = new AtomicInteger();
  private AtomicInteger peakRequestsPerMinute = new AtomicInteger();
  private ScheduledExecutorService requestCountingExecServ;
  
  private static Object monthlyLock = new Object();
  private static volatile RotatingAccessLog monthlyLogger = null;

  /** 
    * Return the singleton monthly RotatingAccessLog object.  
    * If the monthly RotatingAccessLog singleton does not already 
    * exist, construct one with the given configuration settings.
    */
  public static final RotatingAccessLog getMonthlyLogger(File logDir) 
  throws Exception
  {
    if(monthlyLogger!=null) return monthlyLogger;
    
    synchronized (monthlyLock) {
      if(monthlyLogger==null) {
        monthlyLogger = new RotatingAccessLog(logDir, true);
      }
    }
    return monthlyLogger;
  }
  
  
  /** 
   * Construct a log handler to write to log files under the specified directory.
   * If the directory doesnt exist, isnt writable, or is null, the handler
   * will just write messages to stderr.
   */
  public RotatingAccessLog(File logDir, boolean monthly)
    throws Exception
  {
    if(logDir==null) throw new NullPointerException("Log directory cannot be null");
    
    this.logDirectory = logDir;
    this.errorLogDateFormat = new ThreadSafeDateFormat("yyyy/MM/dd HH:mm:ss z");
    this.loggingExtras = true;

    requestCountingExecServ = Executors.newSingleThreadScheduledExecutor(new ThreadFactory() {
        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "RotatingAccessLog-counter");
            t.setDaemon(true);
            return t;
        }
    });
    requestCountingExecServ.scheduleAtFixedRate(new Runnable() {
        @Override
        public void run() {
            rotateRequestsPerMinute();
        }
    }, 1, 1, TimeUnit.MINUTES);
    
    LogRotater logRotater = null;
    if(monthly) {
      logRotater = new MonthlyRotater();
    } else {
      logRotater = new DailyRotater();
    }
    
    // make sure the log directory exists and is a directory
    if (logDirectory.exists()) {
      if (!logDirectory.isDirectory())
        throw new Exception("\"" + logDirectory.getAbsolutePath() + "\" is not a directory.");
    } else {
      logDirectory.mkdirs();
    }
    
    // allow the rotater to initialize itself now that all the settings are loaded
    logRotater.init();
      
    // kick off the rotater
    rotaterThread = new Thread(logRotater);
    rotaterThread.setPriority(Thread.MIN_PRIORITY);
    rotaterThread.setDaemon(true);
    rotaterThread.start();
    
    // wait for the log rotater to get started
    while(!logRotater.initialized()) {
      try { Thread.sleep(500); } catch (Throwable t) {}
    }
    
    logError(ERRLOG_LEVEL_INFO, "Started new run.");
    
    flusherThread = new Thread(this);
    flusherThread.setDaemon(true);
    flusherThread.start();
  }
  
  public void setLoggingExtras(boolean logExtras) {
    this.loggingExtras = logExtras;
  }
  
  /** 
    * Sets the level at which messages equal to or over will be logged.
    */
  public void setErrorLogLevel(int newLogLevel) {
    errorLoggingLevel = newLogLevel;
  }
  
  private static String removeNewlines(String s) {
      return s.replace("\n", "\\n").replace("\r", "\\r");
  }
  
  public void logAccessAndExtra(String accessLogStr, String extraLogStr) {
      requestsCurrentMinute.incrementAndGet();
      synchronized(ACCESS_LOG_LOCK) {
          if (accessWriter == null) {
              System.err.println(accessLogStr);
          } else {
              try {
                  accessWriter.write(removeNewlines(accessLogStr));
                  accessWriter.write('\n');
              } catch (Exception e) {
                  System.err.println("Error writing to access log: (" + e + "): " + accessLogStr);
              }
          }
          if (extraWriter == null) {
              if (extraLogStr != null) System.err.println(extraLogStr);
          } else {
              try {
                  if (extraLogStr != null) extraWriter.write(removeNewlines(extraLogStr));
                  extraWriter.write('\n');
              } catch (Exception e) {
                  System.err.println("Error writing to extra log: (" + e + "): " + extraLogStr);
              }
          }
      }
  }
  
  /** 
    * Write a message to the error log
    */
  public void logError(int level, String logString) {
    if (level < errorLoggingLevel || logString == null)    // No-op in either case
      return;
    
    String msg = "\"" + errorLogDateFormat.format(new Date()) + "\" " + level + ' ' + logString;
    
    // If level is "fatal", write to stderr
    // even if writing to the error log, too
    
    if ((level == ERRLOG_LEVEL_FATAL) || (errorWriter == null))
      System.err.println(msg);
    
    if (errorWriter != null) {
      synchronized(ERROR_LOG_LOCK) {
        try {
          errorWriter.write(msg + '\n');
          errorWriter.flush();
        } catch (Throwable e) {
          System.err.println("Error (" + e + ") writing \"" + logString + "\" to error log.");
        }
      }
    }
  }

  
  /**
   * Sets the file where access log entries will be written.  If the file already exists
   * then new entries will be appended to the file.
   */
  private void setAccessLogFile(File newAccessLogFile)
  throws IOException
  {
    synchronized(ACCESS_LOG_LOCK) {
      // close the old access log
      if(accessWriter!=null) {
        accessWriter.flush();
        accessWriter.close();
        accessWriter = null;
      }
      
      if(loggingAccesses) {
        accessWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newAccessLogFile.getAbsolutePath(), true),"UTF-8"),
                                          ACCESS_LOG_BUFFER_SIZE);
      }
    }
  }
  
  /**
   * Sets the file where extra log entries will be written.  If the file already exists
   * then new entries will be appended to the file.
   */
  private void setExtraLogFile(File newExtraLogFile)
  throws IOException
  {
    synchronized(ACCESS_LOG_LOCK) {
      // close the old extra log
      if(extraWriter!=null) {
        extraWriter.flush();
        extraWriter.close();
        extraWriter = null;
      }
      
      if(loggingExtras) {
        extraWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(newExtraLogFile.getAbsolutePath(), true),"UTF-8"),
                                          EXTRA_LOG_BUFFER_SIZE);
      }
    }
  }
  
  
  /*
   * Sets the file where error log entries will be written.  If the file already exists
   * then new entries will be appended to the file.
   */    
  private void setErrorLogFile(File newErrorLogFile)
    throws IOException
  {
    synchronized(ERROR_LOG_LOCK) {
      // close the old error log
      Writer oldWriter = null;
      try {
        oldWriter = errorWriter;
        errorWriter = null;
        
        FileOutputStream errf = new FileOutputStream(newErrorLogFile.getAbsolutePath(), true);
        System.setErr(new PrintStream(errf));         // Redirect stderr to the error log
        errorWriter = new OutputStreamWriter(errf,"UTF-8");
      } finally {
        try {
          if(oldWriter!=null)
            oldWriter.close();
        } catch (Throwable t) {}
      }
    }
  }
  
  
  /**
   * The run() implementation for the flusher thread:
   * Flush the Access-Log output about every 60 seconds (asynchronously, to
   * minimize the impact on server speed).  (Error-log output is flushed with
   * each write.)
   */
  public void run() {
    while (continuing) {
      try {
        synchronized(ACCESS_LOG_LOCK) {
            if (accessWriter != null)
                accessWriter.flush();
            if (extraWriter != null)
                extraWriter.flush();
        }
      } catch (Exception e) { /* Ignore */ }
      
      try {
        Thread.sleep(60000);
      } catch (Exception e) { /* Ignore */ }
    }
  }
  
  
  /**
    * Stop the flusher thread and close the logs.
   */
  public void shutdown() {
    continuing = false;                             // Tell flusher thread to quit
    
    if (flusherThread != null) {
      synchronized(ACCESS_LOG_LOCK) {                   // Wake the flusher thread, if it's asleep
          try { flusherThread.interrupt(); } catch (Exception e) { /* Ignore */ }
          try { rotaterThread.interrupt(); } catch (Exception e) { /* Ignore */ }
      }
    }
    
    synchronized (ERROR_LOG_LOCK) {
        if (errorWriter != null) {
            try { errorWriter.close(); } catch (Exception e) { /* Ignore */ }
        }
    }

    synchronized (ACCESS_LOG_LOCK) {
        if (accessWriter != null) {
            try { accessWriter.close(); } catch (Exception e) { /* Ignore */ }
        }
        
        if (extraWriter != null) {
            try { extraWriter.close(); } catch (Exception e) { /* Ignore */ }
        }
    }
  }
  
  private void rotateRequestsPerMinute() {
    int newRequestsPastMinute = requestsCurrentMinute.getAndSet(0);
    requestsPastMinute.set(newRequestsPastMinute);
    int pastPeak = peakRequestsPerMinute.get();
    if (newRequestsPastMinute > pastPeak) {
        peakRequestsPerMinute.set(newRequestsPastMinute);
    }
  }
  
  public AtomicInteger getRequestsPastMinute() {
      return requestsPastMinute;
  }

  public AtomicInteger getPeakRequestsPerMinute() {
    return peakRequestsPerMinute;
  }
  
  private abstract class LogRotater
    implements Runnable
  {
    private boolean isInitialized = false;
    
    /**
    * Initialize the log rotater
     */
    public void init() {}
    
    /**
      * Return the next time that the logs should be rotated in milliseconds
     */
    public abstract long getNextRotationTime(long currentTime);
    
    /**
      * Return the suffix that should be appended to access/error log file names
     * for the time period containing the given time.
     */
    public abstract String getLogFileSuffix(long currentTime);
    
    public boolean initialized() {
      return isInitialized;
    }
    
    public void run() {
      while(continuing) {
        long now = System.currentTimeMillis();
        
        try {
          // get the name of the log file for the current period
          String logFileSuffix = getLogFileSuffix(now);
          setErrorLogFile(new File(logDirectory, HSG.ERROR_LOG_FILE_NAME_BASE + logFileSuffix));
          synchronized (ACCESS_LOG_LOCK) {
              setAccessLogFile(new File(logDirectory, HSG.ACCESS_LOG_FILE_NAME_BASE + logFileSuffix));
              setExtraLogFile(new File(logDirectory, HSG.EXTRA_LOG_FILE_NAME_BASE + logFileSuffix));
          }
        } catch (Throwable t) {
          System.err.println("Error setting log files: "+t);
          t.printStackTrace(System.err);
        }
        isInitialized = true;
        
        // wait until the next rotation time
        long nextRotationTime = getNextRotationTime(now);
        while(continuing && nextRotationTime > System.currentTimeMillis()) {
          try {
            Thread.sleep(Math.max(0, nextRotationTime - System.currentTimeMillis()));
          } catch (Throwable t) { }
        }
      }
    }
    
    /**
      * Return a date-stamp for the given date.
     */
    protected String getSuffixForDate(Calendar cal) {
      return "-"+String.valueOf(cal.get(Calendar.YEAR)*10000 +
                                (cal.get(Calendar.MONTH)+1)*100 +
                                cal.get(Calendar.DAY_OF_MONTH));
    }
  }
  
  
  class MonthlyRotater
    extends LogRotater
  {
    protected Calendar cal = Calendar.getInstance();
    
    /**
    * Return the next time that the logs should be rotated in milliseconds
     */
    public long getNextRotationTime(long currentTime) {
      cal.setTime(new Date(currentTime));
      int thisMonth = cal.get(Calendar.MONTH);
      while(cal.get(Calendar.MONTH)==thisMonth)
        cal.add(Calendar.DATE, 1);
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 1);
      cal.set(Calendar.MILLISECOND, 0);
      return cal.getTime().getTime();
    }
    
    /**
      * Return the suffix that should be appended to access/error log file names
     * for the time period containing the given time.
     */
    public String getLogFileSuffix(long currentTime) {
      cal.setTime(new Date(currentTime));
      while(cal.get(Calendar.DAY_OF_MONTH)!=1)
        cal.add(Calendar.DATE, -1);
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 1);
      
      return "-"+String.valueOf(cal.get(Calendar.YEAR)*100 +
                                (cal.get(Calendar.MONTH)+1));
    }
  }
  
  
  class DailyRotater
    extends LogRotater
  {
    protected Calendar cal = Calendar.getInstance();
    
    /**
    * Return the next time that the logs should be rotated in milliseconds
     */
    public long getNextRotationTime(long currentTime) {
      cal.setTime(new Date(currentTime));
      cal.add(Calendar.DATE, 1);
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 1);
      return cal.getTime().getTime();
    }
    
    /**
      * Return the suffix that should be appended to access/error log file names
     * for the time period containing the given time.
     */
    public String getLogFileSuffix(long currentTime) {
      cal.setTime(new Date(currentTime));
      cal.set(Calendar.HOUR_OF_DAY, 0);
      cal.set(Calendar.MINUTE, 0);
      cal.set(Calendar.SECOND, 1);
      return getSuffixForDate(cal);
    }
  }
  
  class DefaultRotater
    extends LogRotater
  {
    protected Calendar cal = Calendar.getInstance();
    
    /**
    * Return the next time that the logs should be rotated in milliseconds
     */
    public long getNextRotationTime(long currentTime) {
      return Long.MAX_VALUE;
    }
    
    /**
      * Return the suffix that should be appended to access/error log file names
     * for the time period containing the given time.
     */
    public String getLogFileSuffix(long currentTime) {
      return "";
    }
  }
  
}
