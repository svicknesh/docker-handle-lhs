/**********************************************************************\
 © COPYRIGHT 2015 Corporation for National Research Initiatives (CNRI);
                        All rights reserved.

        The HANDLE.NET software is made available subject to the
      Handle.Net Public License Agreement, which may be obtained at
          http://hdl.handle.net/20.1000/103 or hdl:20.1000/103
\**********************************************************************/

package net.handle.hdllib;

import java.security.*;

public class PublicKeyAuthenticationInfo
  extends AuthenticationInfo
{
  private PrivateKey privateKey;
  private byte userIdHandle[];
  private int userIdIndex;

  public PublicKeyAuthenticationInfo(byte userIdHandle[], int userIdIndex, 
                                     PrivateKey privateKey)
  {
    this.privateKey = privateKey;
    this.userIdHandle = userIdHandle;
    this.userIdIndex = userIdIndex;
  }

  
  /***********************************************************************
   * Get the identifier for the type of authentication performed.  In this
   * case, the authentication type is AT_SECRET_KEY.
   ***********************************************************************/
  public byte[] getAuthType()
  {
    return Common.PUBLIC_KEY_TYPE;
  }


  /***********************************************************************
   * Sign the given nonce and requestDigest given as a challenge to the
   * given request.  The implementation of this method should also probably
   * verify that the client did in fact send the specified request, and 
   * that the associated digest is a valid digest of the request.
   * @return a signature of the concatenation of nonce and requestDigest.
   ***********************************************************************/
  public byte[] authenticate(ChallengeResponse challenge, AbstractRequest request)
    throws HandleException
  {
    // need to verify that this is actually a digest of the specified request
    byte origDigest[] = Util.doDigest(challenge.rdHashType,
                                      request.getEncodedMessageBody());
    if(!Util.equals(origDigest, challenge.requestDigest)) {
      throw new HandleException(HandleException.SECURITY_ALERT,
                                "Asked to sign unidentified request!");
    }

    byte signatureBytes[] = null;
    byte sigHashType[] = null;
    // sign the nonce, digest, and return the result
    try {
      Signature signer = null;
      String alg = privateKey.getAlgorithm().trim();
      signer = Signature.getInstance(Util.getDefaultSigId(alg, challenge));
      signer.initSign(privateKey);
      signer.update(challenge.nonce);
      signer.update(challenge.requestDigest);
      signatureBytes = signer.sign();
      sigHashType = Util.getHashAlgIdFromSigId(signer.getAlgorithm());
      
      int offset = 0;
      byte signature[] = new byte[signatureBytes.length + sigHashType.length +
                                  2*Encoder.INT_SIZE];
      offset += Encoder.writeByteArray(signature, offset, sigHashType);
      offset += Encoder.writeByteArray(signature, offset, signatureBytes);
      return signature;
    } catch (Exception e) {
      e.printStackTrace(System.err);
      throw new HandleException(HandleException.INTERNAL_ERROR,
                                "Unable to sign challenge: ",e);
    }
  }


  /***********************************************************************
   * Get the handle that identifies the user that is 
   * represented by this authentication object.
   ***********************************************************************/
  public byte[] getUserIdHandle()
  {
    return userIdHandle;
  }

  /***********************************************************************
   * Get the index of the handle value that identifies this user.
   * The returned index value of the handle that identifies this user
   * should contain a value with a type (public key, secret key, etc)
   * that corresponds to the way that this user is authenticating.
   ***********************************************************************/
  public int getUserIdIndex()
  {
    return userIdIndex;
  }
  

  /** Return the byte-encoded representation of the secret key. */
  public PrivateKey getPrivateKey() {
    return privateKey;
  }

  public String toString() {
    return "public_key:"+String.valueOf(userIdIndex)+':'+
      ((userIdHandle==null)?"null":Util.decodeString(userIdHandle));
  }
  
  public boolean equals(Object obj) {
      if(obj==null) return false;
      if(!(obj instanceof PublicKeyAuthenticationInfo)) return false;
      if(super.equals(obj)) return true;
      PublicKeyAuthenticationInfo other = (PublicKeyAuthenticationInfo) obj;
      boolean sameIdentity = Util.equals(getUserIdHandle(),other.getUserIdHandle()) && getUserIdIndex()==other.getUserIdIndex();
      if(!sameIdentity) return false;
      byte[] encKey = privateKey.getEncoded();
      byte[] otherEncKey = other.privateKey.getEncoded();
      if(encKey==null || otherEncKey==null) return false;
      return Util.equals(encKey,otherEncKey);
  }
}
