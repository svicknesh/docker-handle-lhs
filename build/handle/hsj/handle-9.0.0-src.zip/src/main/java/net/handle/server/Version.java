package net.handle.server;
public class Version {
    public static final String version="9.0.0";
}